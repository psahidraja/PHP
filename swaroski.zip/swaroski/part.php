<?php
require_once('Models/FunctionDataSet.php');
require_once('Models/FunctionData.php');
//require_once('Models/PartDataSet.php');
$view = new stdClass();

$functionDataSet = new FunctionDataSet();
$view->CategoryDataSet = $functionDataSet->fetchAllCategories();

$brandDataSet = new FunctionDataSet();
$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);

/*$productDataSet = new ProductDataSet();
$view->ProductDataSet = $productDataSet->fetchAllProducts();
var_dump($view->ProductDataSet);*/
require_once('Views/part.phtml');
