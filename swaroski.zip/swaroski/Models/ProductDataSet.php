<?php

require_once('Models/Database.php');
require_once('Models/FunctionData.php');
require_once('Models/ProductData.php');

class ProductDataSet
{
    protected $_dbHandle, $_dbInstance;


    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllCategories()
    {
        $sqlQuery = 'SELECT * FROM categories';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_cats = $statement->fetch()) {

            $dataSet[] = new FunctionData($row_cats);
        }

        return $dataSet;
    } //end of fetchAllBrands function here

    public function fetchAllBrands()
    {
        $sqlQuery = 'SELECT * FROM brands';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_brands = $statement->fetch()) {


            $dataSet[] = new FunctionData($row_brands);


        }
        return $dataSet;
    } //end of fetchAllBrands function here overriding

    public function deleteItem($username, $product_id)
    {

        $sqlQuery = "DELETE from cart WHERE user_id = '$username' AND product_id = '$product_id'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }

//this function if products page
    public function fetchAllProducts()
    {

        $sqlQuery = 'select * from products';

        if ($_GET[sort] == "lowToHigh") {
            $sqlQuery .= " ORDER BY product_price ASC";
        } elseif ($_GET[sort] == "highToLow") {
            $sqlQuery .= " ORDER BY product_price DESC";
        }

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_products = $statement->fetch()) {
            $dataSet[] = new ProductData($row_products);
        }
        return $dataSet;


        /*<div id='single_product'>
                <h3>$pro_title</h3>
            <img src='admin_area/product_images/$pro_image' width='180' height='180'/>

            <!-- you can delete the word proce if you want after:-->
            <p><b> Price: £ $pro_price</b></p>

            <a href='details.php?pro_id=$pro_id' style='float:left; color:black'>Details</a>



            <a href='index.php?add_cart=$pro_id'><button style='float:right; color:crimson'>Add to cart</button></a>

        </div>

        ";

                        }
                    }

                }

            }*/
    }

    //getting the total added items
//    public function total_items(){
//        if($sqlQuery = mysqli_query("SELECT product_id FROM products ORDER BY product_id")) {
//            /* determine number of rows result set */
//            $statement = mysqli_num_rows($sqlQuery);
//            printf("%d \n", $statement);
//            /* close result set */
//            mysqli_free_result($sqlQuery); }
//    }

    //this method is used for product_detail.php page
    public function fetchProducts($product_id)
    {
        $sqlQuery = "SELECT * FROM products where product_id = $product_id";

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        while ($row = $statement->fetch()) {
            //var_dump($row);
            $dataSet = new ProductData($row);
        }
        return $dataSet;
    }

    //this is for searching the products thorugh seach bar
    public function searchProduct($search)
    {
        $sqlQuery = "SELECT * FROM products where product_title LIKE '%$search%'";
//        var_dump($sqlQuery);
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row = $statement->fetch()) {
//            echo '<img src="images/' . $row['product_image'] . '"alt="no Image"/>';
//            echo "<br>";
//            echo  $row['product_title'] ."<br>";
////            echo "<br>";
//            echo  "£" . $row['product_price'] ."<br>";
////            echo "<br>";
//            echo "In stock " . $row['product_quantity'] ."<br>";;
////            echo "<br>";
//            echo "<a class='detail' href='product_detail.php?id=" . $row['product_id'] . "'>Details</a>";
            $dataSet[] = new ProductData($row);
        }
        return $dataSet;
    }

    //creating the shopping cart for the website

}

