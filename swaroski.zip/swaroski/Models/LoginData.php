<?php

class LoginData {
    
    protected $user_id, $first_name, $last_name, $user_name, $password, $c_password, $u_email, $address, $mob_number;
    
    public function __construct($dbRow) {
        $this->user_id = $dbRow['user_id'];
        $this->first_name = $dbRow['first_name'];
        $this->last_name = $dbRow['last_name'];
        $this->user_name = $dbRow['user_name'];
        $this->password = $dbRow['password'];
        $this->c_password = $dbRow['c_password'];
        $this->u_email = $dbRow['u_email'];
        $this->address = $dbRow['address'];
        $this->mob_number = $dbRow['mob_number'];
    }

    public function getfirstName()
    {
        return $this->first_name;
    }
    public function getlastName()
    {
        return $this->last_name;
    }
    public function getuserName()
    {
        return $this->user_name;
    }
    public function getpassword()
    {
        return $this->password;
    }
    public function getconfirmPassword()
    {
        return $this->c_password;
    }
    public function getuserEmail()
    {
        return $this->u_email;
    }
    public function getaddress()
    {
        return $this->address;
    }
    public function getmobileNumber()
    {
        return $this->mob_number;
    }

} ?>