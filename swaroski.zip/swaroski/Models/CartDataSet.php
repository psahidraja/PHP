<?php

require_once ('Models/Database.php');
require_once ('Models/CartData.php');
require_once ('Models/ProductData.php');


class CartDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function addToBasket($quantity, $product_id,$user_id){
        //$encrypt_pass = password_hash($password, PASSWORD_BCRYPT);
        $sqlquery = "INSERT INTO cart (quantity, product_id,user_id) 
        VALUES ($quantity, $product_id, $user_id)";
//        echo $sqlquery;
        //var_dump($_SESSION);

        $statement = $this->_dbHandle->prepare($sqlquery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement


        //if($this->_dbHandle->exec($sqlquery)){
            //echo "You have registered successfully";}
            //echo "<script type='text/javascript'>alert('You have registered successfully!')</script>";}
            //else{
            //echo "please fill all the fields";
            //      echo "<script type='text/javascript'>alert('please fill in all the fields!')</script>";

            //}
            //$this->_dbHandle->exec($sqlquery); you need this this is orginial
//        echo $first_name;
//        echo $sqlquery;
//        echo  "<br>";
           // var_dump($sqlquery);


        //}

    }

    public function updateuser($quantity, $product_id,$user_id){
        //$encrypt_pass = password_hash($password, PASSWORD_BCRYPT);
        $sqlquery = "INSERT INTO cart (quantity, product_id,user_id) 
        VALUES ($quantity, $product_id, $user_id)";
//        echo $sqlquery;
        //var_dump($_SESSION);

        $statement = $this->_dbHandle->prepare($sqlquery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        }


    public function getProducts($user_id)
    {
        $sqlQuery = "SELECT * FROM products,cart where  cart.user_id = '$user_id' AND cart.product_id=products.product_id";

//        $sqlQuery = "SELECT * FROM products,cart ";

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet =[];
        while ($row = $statement->fetch()) {
            //var_dump($row);
            $dataSet[] = new CartData($row);
        }
        return $dataSet;
    }

    /*this is for deleting the products */
    public function deleteproduct($cart_id)
    {
        $sqlQuery = "DELETE from cart WHERE cart_id = '$cart_id'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }

//    /*this is for deleting all the products */
//    public function deleteproducts($cart_id)
//    {
//        $sqlQuery = "DELETE * from cart WHERE cart_id = '$cart_id'";
//        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//        $statement->execute(); // execute the PDO statement
//    }

//    public function getGrandTotal() {
//        $sqlQuery = "SELECT SUM(";
//        //$sqlQuery = "SELECT * FROM products,cart ";
//
//        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//        $statement->execute(); // execute the PDO statement
//
//        $dataSet =[];
//        while ($row = $statement->fetch()) {
//            //var_dump($row);
//            $dataSet[] = new ProductData($row);
//        }
//        return $dataSet;
//    }
}