<?php

require_once ('Models/Database.php');
require_once ('Models/FunctionData.php');

class FunctionDataSet
{
    protected $_dbHandle, $_dbInstance;


        
    public function __construct() {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function fetchAllCategories() {
        $sqlQuery = 'SELECT * FROM categories';
                
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
        
        $dataSet = [];
        while ($row_cats = $statement->fetch()){

                $dataSet[] = new FunctionData($row_cats);
            }


        return $dataSet;
    } //end of fetchAllBrands function here

    public function fetchAllBrands() {
        $sqlQuery = 'SELECT * FROM brands';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_brands = $statement->fetch()){


                $dataSet[] = new FunctionData($row_brands);


        }
        return $dataSet;
    } //end of fetchAllBrands function here overriding

//this function if products page
    public function fetchAllProducts() {

        $sqlQuery = "select * from products order by RAND() LIMIT 0,6";

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_products = $statement->fetch()){


            $dataSet[] = new FunctionData($row_products);


        }
        return $dataSet;


	
	/*<div id='single_product'>
			<h3>$pro_title</h3>
		<img src='admin_area/product_images/$pro_image' width='180' height='180'/>
		
		<!-- you can delete the word proce if you want after:-->
		<p><b> Price: £ $pro_price</b></p>
		
		<a href='details.php?pro_id=$pro_id' style='float:left; color:black'>Details</a>
			
			
			
		<a href='index.php?add_cart=$pro_id'><button style='float:right; color:crimson'>Add to cart</button></a>
		
	</div>
						
	";

                    }
                }

            }

        }*/
    }

}


