<?php

class CartData {

    protected $cart_id,$product_id,$user_id,$quantity,$product_price,$product_title;

    public function __construct($dbRow) {
        $this->cart_id = $dbRow['cart_id'];
        $this->product_id = $dbRow['product_id'];
        $this->user_id = $dbRow['user_id'];
        $this->product_quantity= $dbRow['quantity'];
        $this->product_price= $dbRow['product_price'];
        $this->product_title = $dbRow['product_title'];
    }

    public function getcartID(){
        return $this->cart_id;
    }
    public function getproductID()
    {
        return $this->product_id;
    }
    public function getuserID()
    {
        return $this->user_id;
    }
    public function getQuantity()
    {
        return $this->product_quantity;
    }
    public function getproductPrice()
    {
        return $this->product_price;
    }
    public function getproductTitle()
    {
        return $this->product_title;
    }

}


