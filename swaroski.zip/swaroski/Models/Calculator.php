<?php
/**
 * Created by PhpStorm.
 * User: stc490
 * Date: 17/10/16
 * Time: 13:58
 */

//class Converter
class Calculator {
    /*
     * Class for converting miles to kilometers and vice versa
     */
    var $number1 = 0, $number2 = 0, $operator = '';
    /*
     * The constructor takes the number and unit and assigns
     * them to the corresponding properties.
     * @param int $number The number to be converted
     * @param string The conversion unit
     */
    public function __construct($number1, $number2, $operator) {
        $this -> number1 = $number1;
        $this -> number2 = $number2;
        $this -> operator = $operator;
    }
    /*
     * Converts the number and return the result
     * @return string The result of the conversion
     */
    public function calculate() {
        echo $this -> operator;
        if ($this -> operator == '+') {
            $result = $this -> number1 + $this->number2;

        } 
		elseif ($this-> operator == '-') {
            $result = $this -> number1 - $this->number2;
        }
		elseif ($this-> operator == '/') {
            $result = $this -> number1 / $this->number2;
        }
		elseif ($this-> operator == '*') {
            $result = $this -> number1 * $this->number2;
        }
		else {
            $result = 'error';
        }
        return $result;
        //return 'Your calculation is: '. $result;
    }
}

