<?php

require_once ('Models/Database.php');
//require_once ('Models/RegisterData.php');
//require_once ('../Views/register.phtml);

class SearchDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function search (){
        $user_query = $_GET['user_query'];
        $statement = $this->_dbHandle->prepare("select * from products where product_keywords like '%$user_query%'");
        //$search->setFetch_Mode(PDO:: FETCHASSOC);

        $statement->execute();

        $dataSet = [];
        while ($row = $statement->fetch()){

            $dataSet[] = new ProductData($row);
        }
        return $dataSet;
    }


}