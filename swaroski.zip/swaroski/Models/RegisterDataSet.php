<?php

require_once ('Models/Database.php');
//require_once ('Models/RegisterData.php');
//require_once ('../Views/register.phtml);

class RegisterDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function registeruser($first_name,$last_name,$user_name,$u_email,$password,$c_password,$address,$c_address,$mob_number){
        //$encrypt_pass = password_hash($password, PASSWORD_BCRYPT);
        $sqlquery = "INSERT INTO users (first_name,last_name,user_name,u_email,password,c_password,address,c_address,mob_number) 
        VALUES ('$first_name','$last_name','$user_name','$u_email','$password','$c_password','$address','$c_address','$mob_number')";

        if($this->_dbHandle->exec($sqlquery)){
            //echo "You have registered successfully";}
         //echo "<script type='text/javascript'>alert('You have registered successfully!')</script>";}
        //else{
                //echo "please fill all the fields";
          //      echo "<script type='text/javascript'>alert('please fill in all the fields!')</script>";

            //}
        //$this->_dbHandle->exec($sqlquery); you need this this is orginial
//        echo $first_name;
//        echo $sqlquery;
//        echo  "<br>";
        var_dump($sqlquery);


    }

}}

























//    public function createAccount() //removed the word $post from brackets
//    {
//        if (isset($_POST['register'])) {
//
//            //you can type echo to check if the following code is working or not
//            $sqlQuery = "insert into users (user_id,first_name,last_name,user_name,password,u_email,address,mob_number)
//    values ('".$_POST['user_id']."', '".$_POST['first_name']."', '".$_POST['last_name']."', '".$_POST['user_name']."', '".$_POST['password']."', '".$_POST['u_email']."', '".$_POST['address']."', '".$_POST['mob_number']."')";
//            echo $sqlQuery;
//            //$statement = $this->_dbHandle->prepare($sqlQuery);
//            //$sqlQuery->exec();
//            $this->_dbHandle-exec($sqlQuery);
//
//            /*if(isset($_POST['register'])){
//                echo "<script>alert('Account has created successfully:)</script>";
//            } else {
//                if(!isset($_POST['register'])){
//                echo "<script>alert('Account has not created successfully:)</script>";
//            }*/
//
//        }
//        }}
//            /*$sqlQuery = "select * from where ip_add='$ip'";
//            $statement = $this->_dbHandle->prepare($sqlQuery);
//            $statement->execute();
//
//            $run_cart = mysqli_query( $sel_cart);
//
//            $check_cart = mysqli_num_rows($run_cart);
//
//            if ($check_cart == 0) {
//
//                $_SESSION['customer_email'] = $c_email;
//
//                echo "<script>alert('Account has been created successfully :), Now you are the member of our company thanks for joining with us')</script>";
//
//                echo "<script>window.open('customer/my_account.php','_self')</script>"; //redirecting the user to its account page
//            } else {
//
//                $_SESSION['customer_email'] = $c_email;
//
//                echo "<script>alert('Account has been created successfully :), Now you are the member of our company thanks for joining with us')</script>";
//
//                echo "<script>window.open('checkout.php','_self')</script>"; //redirecting the user to its account page
//
//
//            }
//
//        }
//
//    }
//}*/