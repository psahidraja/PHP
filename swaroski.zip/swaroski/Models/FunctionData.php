<?php

class FunctionData {
    
    protected $cat_title, $brand_title;
    
    public function __construct($dbRow) {
        $this->cat_title = $dbRow['cat_title'];
        $this->brand_title = $dbRow['brand_title'];
    }

    public function getcatTitle()
    {
        return $this->cat_title;
    }

    public function getbrandTitle()
    {
        return $this->brand_title;
    }


}


