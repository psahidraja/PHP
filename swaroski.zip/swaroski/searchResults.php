<?php
session_start();
require_once('Models/Database.php');
require_once('Models/FunctionData.php');
require_once('Models/FunctionDataSet.php');
require_once('Models/ProductDataSet.php');

$view = new stdClass();

$functionDataSet = new FunctionDataSet();
$view->CategoryDataSet = $functionDataSet->fetchAllCategories();

$brandDataSet = new FunctionDataSet();
$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);

$productDataSet = new ProductDataSet();
if (isset($_POST['go'])) {

    $view->ProductData = $productDataSet->searchProduct($_POST['search']);
}
//    if (!isset($_POST['go'])) {
//        echo "no results found";
//    }


//$view->ProductDataSet = $productDataSet->fetchAllProducts();
//var_dump($view->ProductDataSet);
require_once('Views/searchResult.phtml');
