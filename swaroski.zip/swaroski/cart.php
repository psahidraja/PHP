<?php
session_start();


require_once('Models/FunctionDataSet.php');
require_once('Models/FunctionData.php');
require_once('Models/CartDataSet.php');
require_once('Models/CartData.php');
require_once('Models/ProductData.php');
require_once('Models/ProductDataSet.php');


$view = new stdClass();

//$functionDataSet = new FunctionDataSet();
//$view->CategoryDataSet = $functionDataSet->fetchAllCategories();
//
//$brandDataSet = new FunctionDataSet();
//$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);

//$quantity = $_POST['availability'];
//$quantity = $_POST['quantity'];
//if(isset($_POST['delete'])){
//    $productDataSet->deleteItem($_SESSION['username'],$_POST['id']);
//    header("Refresh:@");
//}
//var_dump($_POST);
if ($_GET['action'] == "add") {
    $cartDataSet = new CartDataSet();
    $quantity = $_POST['quantity'];

//    if (isset($_GET['quantity']) && $_GET['quantity'] > 1){
//        echo "quantity is biggert then one";
//        $quantity = $quantity;
//    }else{
//        $quantity = $_GET['quantity'];
//    }
    $view->CartDataSet = $cartDataSet->addToBasket($_POST['quantity'], $_GET['id'], $_SESSION['id']);
//    var_dump($view->cartDataSet);
}

$cartDataSet = new CartDataSet();

//this is for deleting individual items
if (isset($_GET['delete'])) {
    $cartDataSet->deleteproduct($_GET['delete']);
}

////this is for removing all the products from cart
//if(isset($_GET['deletes'])){
//    $cartDataSet->deleteproducts($_GET['deletes']);
//}

$view->CartDataSet = $cartDataSet->getProducts($_SESSION['id']);
//var_dump($view->CartDataSet);

require_once('Views/cart.phtml');
