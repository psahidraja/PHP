<!DOCTYPE HTML>
<html lang="en-US">
<head>
	<meta charset="UTF-8">
	<title></title>
</head>
<body>
	
	<form action="" method="post">
		
		<div class="filter">
			<ul>
				<h3>Brands</h3>
				<li><a href="product.php">Tee's</a></li>
				<li><a href="product.php">Hoodies</a></li>
				<li><a>Shoes</a></li>
				<li><a>Trousers</a></li>
				<li><a href="product.php">Sweatshirts</a></li>
				
				<label>Sort By</label>
				<select name="sort">
					<option value="low-to-high">Low to Hight</option>
                    <option value="high-to-low">High to Low</option>
                    <option value="white">White</option>
                    <option value="red">Red</option>
                    <option value="black">Black</option>
				</select>
				<input type="submit" name="filter" value="Go">
			</ul>			
		</div>
	</form>
	
	
</body>
</html>