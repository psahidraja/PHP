<?php

class UpdateUserData {
    
    protected $user_id, $first_name, $last_name, $user_name, $u_email, $password, $c_password,$address,$c_address, $mob_number;
    
    public function __construct($dbRow) {
        $this->user_id = $dbRow['user_id'];
        $this->first_name = $dbRow['first_name'];
        $this->last_name = $dbRow['last_name'];
        $this->user_name = $dbRow['user_name'];
        $this->u_email = $dbRow['u_email'];
        $this->password = $dbRow['password'];
        $this->c_password = $dbRow['c_password'];
        $this->address = $dbRow['address'];
        $this->c_address = $dbRow['c_address'];
        $this->mob_number = $dbRow['mob_number'];
    }

    public function getuserID()
    {
        return $this->user_id;
    }
    public function getfirstName()
    {
        return $this->first_name;
    }
    public function getlastName()
    {
        return $this->last_name;
    }
    public function getuserName()
    {
        return $this->user_name;
    }
    public function getuserEmail()
    {
        return $this->u_email;
    }
    public function getpassword()
    {
        return $this->password;
    }
    public function getconfirmPassword()
    {
        return $this->c_password;
    }
    public function getaddress()
    {
        return $this->address;
    }
    public function getconfirmAddress()
    {
        return $this->c_address;
    }
    public function getmobileNumber()
    {
        return $this->mob_number;
    }

} ?>