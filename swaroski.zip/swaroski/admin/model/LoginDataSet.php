<?php
session_start();

require_once ('model/Database.php');
require_once ('model/LoginData.php');
//require_once ('../Views/register.phtml);

class LoginDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function login($user_name,$password){

        $sqlQuery = "select * from admin WHERE u_email = '$user_name' AND password = '$password'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $row = $statement->fetch();
        return $row['admin_id'];
    }

//    public function login($user_name,$password){
//
//        $sqlQuery = "select * from users WHERE u_email = '$user_name' AND password = '$password'";
//        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
//        $statement->execute(); // execute the PDO statement
//
//
//
//        $dataSet = [];
//        while ($row = $statement->fetch(PDO::FETCH_ASSOC)) {
//            $dataSet = $row;
//        }
//        var_dump($dataSet);
//
//        $result = password_verify($password, $dataSet['password']);
//
//        if ($result) {
//            return $dataSet;
//        }
//        else {
//            echo "ERRRRRRRRRRRRRRRRR";
//        }
//
//    }
}


