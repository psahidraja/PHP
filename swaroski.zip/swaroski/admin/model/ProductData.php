<?php

class ProductData {
    
    protected $product_id, $product_title,$product_cat,$product_brand,$product_price,$product_quantity,$product_desc,$product_image,$product_keywords;
    
    public function __construct($dbRow) {
        $this->product_id = $dbRow['product_id'];
        $this->product_title = $dbRow['product_title'];
        $this->product_cat = $dbRow['product_cat'];
        $this->product_brand = $dbRow['product_brand'];
        $this->product_price = $dbRow['product_price'];
        $this->product_quantity = $dbRow['product_quantity'];
        $this->product_desc = $dbRow['product_desc'];
        $this->product_image = $dbRow['product_image'];
        //if ($dbRow['product_image']) $this->product_image = 'yes'; else $this->product_image = 'no';
        $this->product_keywords = $dbRow['product_keywords'];
    }

    public function getproductID(){
        return $this->product_id;
    }
    public function getproductTitle()
    {
        return $this->product_title;
    }
    public function getproductCat()
    {
        return $this->product_cat;
    }
    public function getproductbrand()
    {
        return $this->product_brand;
    }
    public function getproductPrice()
    {
        return $this->product_price;
    }
    public function getproductQuantity()
    {
        return $this->product_quantity;
    }
    public function getproductDesc()
    {
        return $this->product_desc;
    }
    public function getproductImage()
    {
        return $this->product_image;
    }
    public function getproductKeywords()
    {
        return $this->product_keywords;
    }
}


