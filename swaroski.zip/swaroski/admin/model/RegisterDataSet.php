<?php

require_once('model/Database.php');
require_once ('model/RegisterData.php');
//require_once ('../view/register.phtml);

class RegisterDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function registeruser($first_name, $last_name, $user_name, $u_email, $password, $c_password, $address, $c_address, $mob_number)
    {
        //$encrypt_pass = password_hash($password, PASSWORD_BCRYPT);
        $sqlquery = "INSERT INTO admin (first_name,last_name,user_name,u_email,password,c_password,address,c_address,mob_number) 
        VALUES ('$first_name','$last_name','$user_name','$u_email','$password','$c_password','$address','$c_address','$mob_number')";

        if ($this->_dbHandle->exec($sqlquery)) {
            //echo "You have registered successfully";}
            //echo "<script type='text/javascript'>alert('You have registered successfully!')</script>";}
            //else{
            //echo "please fill all the fields";
            //      echo "<script type='text/javascript'>alert('please fill in all the fields!')</script>";

            //}
            //$this->_dbHandle->exec($sqlquery); you need this this is orginial
//        echo $first_name;
//        echo $sqlquery;
//        echo  "<br>";
//            var_dump($sqlquery);
        }
    }
}