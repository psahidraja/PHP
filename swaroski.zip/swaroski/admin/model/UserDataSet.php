<?php

require_once('model/Database.php');
require_once('model/UserData.php');

class UserDataSet
{
    protected $_dbHandle, $_dbInstance;


    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    //this function if products page
    public function fetchAllUsers()
    {
        $sqlQuery = 'select * from users';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_users = $statement->fetch()) {
            $dataSet[] = new UserData($row_users);
        }
        return $dataSet;
    }

    /*this is for deleting the users */
    public function deleteuser($user_id)
    {
        $sqlQuery = "DELETE from users WHERE user_id = '$user_id'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }

    //this is for searching the users thorugh seach bar
    public function searchUsers($search)
    {
        $sqlQuery = "SELECT * FROM users where first_name LIKE '%$search%'";
//        var_dump($sqlQuery);
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row = $statement->fetch()) {
//            echo '<img src="images/' . $row['product_image'] . '"alt="no Image"/>';
//            echo "<br>";
//            echo  $row['product_title'] ."<br>";
////            echo "<br>";
//            echo  "£" . $row['product_price'] ."<br>";
////            echo "<br>";
//            echo "In stock " . $row['product_quantity'] ."<br>";;
////            echo "<br>";
//            echo "<a class='detail' href='product_detail.php?id=" . $row['product_id'] . "'>Details</a>";
            $dataSet[] = new UserData($row);
        }
        return $dataSet;
    }
}