<?php
session_start();

require_once ('model/Database.php');
require_once ('model/CheckData.php');
//require_once ('../view/register.phtml);

class CheckDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function checkid($reference){

        $sqlQuery = "select * from check WHERE check_id = '$reference'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $row = $statement->fetch();
        return $row['check_id'];
    }

}


