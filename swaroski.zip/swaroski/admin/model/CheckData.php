<?php

class CheckData {
    
    protected $check_id, $reference;
    
    public function __construct($dbRow) {
        $this->check_id = $dbRow['check_id'];
        $this->reference = $dbRow['reference'];
    }

    public function getcheckID()
    {
        return $this->check_id;
    }
    public function getreference()
    {
        return $this->reference;
    }

} ?>