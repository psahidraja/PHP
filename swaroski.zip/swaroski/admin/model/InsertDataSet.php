<?php

require_once ('Database.php');
require_once ('model/InsertData.php');
//require_once ('view/indert.phtml);

class InsertProductDataSet
{
    protected $_dbHandle, $_dbInstance;

    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    public function insertProduct($product_title,$product_cat,$product_brand,$product_image,$product_price,$product_desc,$product_keywords){
        $sqlQuery = "INSERT INTO stc490_swaroski.products (product_title,product_cat,product_brand,product_image,product_price,product_desc,product_keywords) 
        VALUES ('$product_title','$product_cat','$product_brand','$product_image','$product_price','$product_desc','$product_keywords')";

        //$statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement

        if($this->_dbHandle->exec($sqlQuery));
            //echo "You have registered successfully";}
            //echo "<script type='text/javascript'>alert('You have registered successfully!')</script>";}
            //else{
            //echo "please fill all the fields";
            //      echo "<script type='text/javascript'>alert('please fill in all the fields!')</script>";

            //}
            //$this->_dbHandle->exec($sqlquery); you need this this is orginial
//        echo $first_name;
//        echo $sqlquery;
//        echo  "<br>";
            //var_dump($sqlQuery);


        }

    }
