<?php

require_once('model/Database.php');
require_once('model/ProductData.php');

class ProductDataSet
{
    protected $_dbHandle, $_dbInstance;


    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    //this function if products page
    public function fetchAllProducts()
    {
        $sqlQuery = 'select * from products';

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_products = $statement->fetch()) {
            $dataSet[] = new ProductData($row_products);
        }
        return $dataSet;
    }

    /*this is for deleting the products */
    public function deleteproduct($product_id)
    {
        $sqlQuery = "DELETE from products WHERE product_id = '$product_id'";
        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement
    }
}