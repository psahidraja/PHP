
<?php
//require_once('../model/InsertDataSet.php');
//require_once('model/FunctionDataSet.php');
//require_once('../Models/FunctionDataSet.php');
//require_once('../Models/FunctionData.php');


$view = new stdClass();


//$functionDataSet = new FunctionDataSet();
//$view->CategoryDataSet = $functionDataSet->fetchAllCategories();
//var_dump($view->CategoryDataSet);

//$insertProductDataSet = new InsertProductDataSet();
//var_dump($view->InsertProductDataSet);
//echo "";


$productTitle = $_POST['product_title'];
//echo $productTitle;

//$productCat = $_POST['product_cat'];
//$functionDataSet = new FunctionDataSet($_POST['product_cat']);
//$view->CategoryDataSet = $functionDataSet->fetchAllCategories();
//var_dump($view->CategoryDataSet);


$productBrand = $_POST['product_brand'];
//$brandDataSet = new FunctionDataSet();
//$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->BrandDataSet);

$productImage = $_POST['product_image'];

$productPrice = $_POST['product_price'];

$productDesc = $_POST['product_desc'];

$productKeywords = $_POST['product_keywords'];


if (isset($_POST['insert_post']))
{
    //echo "product added";
    $insertProductDataSet = $insertProductDataSet->insertProduct($productTitle,$productTitle,$productBrand,$productImage,$productPrice,$productDesc,$productKeywords);
    //echo "<script type='text/javascript'>alert('You have added product successfully!')</script>";}
    //var_dump($insertProductDataSet);
}


require_once('view/insert.phtml');

