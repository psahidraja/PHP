<?php

require_once('model/UpdateUserDataSet.php');
require_once('model/UpdateUserData.php');

$view = new stdClass();

if ($_GET['action'] == "add") {
    $updateUserDataSet = new UpdateUserDataSet();
    $view->UpdateUserDataSet = $updateUserDataSet->updateuser($user_id);
    var_dump($view->UpdateUserDataSet);
//    $view->UpdateUserDataSet = $updateUserDataSet->updateuser(1, $_GET['id'],$_SESSION['id']);
//    var_dump($view->cartDataSet);
}

$updateUserDataSet = new UpdateUserDataSet();
$view->UpdateUserDataSet = $updateUserDataSet->getUsers($_SESSION['id']);
//var_dump($view->CartDataSet);

//if ($_GET['action'] == "add") {
//    $cartDataSet = new CartDataSet();
//    $view->CartDataSet = $cartDataSet->addToBasket(1, $_GET['id'],$_SESSION['id']);
////    var_dump($view->cartDataSet);
//}

//$cartDataSet = new CartDataSet();
//$view->CartDataSet = $cartDataSet->getProducts($_SESSION['id']);
////var_dump($view->CartDataSet);

require_once('view/updateuser.phtml');
