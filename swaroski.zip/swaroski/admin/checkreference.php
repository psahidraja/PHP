<?php
session_start();
require_once('model/CheckDataSet.php');


$view = new stdClass();
$checkDataSet = new CheckDataSet();

$checkID = $_POST['email'];
//$password = $_POST['pass'];


if (isset($_POST['login'])) {


    $checkID = $checkDataSet->checkid($checkID);
//    if(!isset($_SESSION['email'])){
//
//        echo "<a href='checkout.php' style='color:red'>Login</a>";
//    }else {
//        echo "<a href='logout.php' style='color:red'>Logout</a>";
//    }
    //echo "You have successfully logged in";

    if ($checkID) {
        $_SESSION['logged_in'] = true;
        //echo "<script type='text/javascript'>alert('You have successfully logged in!')</script>";
        $_SESSION['checkID'] = $checkID;
//        $_SESSION['id'] = $checkID;
//        echo $_SESSION['username'];
//        $_SESSION['cusIDSession'] = $loginDataSet['first_name'];
//        echo "<br>";
//        echo"USER ID: " . $_SESSION['cusIDSession'];
//
//        if (isset($_SESSION['cusIDSession'])) {
//            echo "YAAAAAAAAAAAAAAAAAAAAA";
//    }

    //echo $_SESSION['username'];
    header('location:register.php?login=success');
    //var_dump($checkDataSet);
}

    else
    {
//       echo "<script type='text/javascript'>alert('Your details is incorrect!')</script>";
    }

}else{
    if(!isset($_POST['login'])){
//         echo "<script type='text/javascript'>alert('password or email is incorrect')</script>";
    }
}
require_once('view/checkreference.phtml');