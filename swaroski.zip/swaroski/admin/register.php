<?php
require_once('model/RegisterDataSet.php');
require_once('view/register.phtml');

$view = new stdClass();
$registerDataSet = new RegisterDataSet();

$firstName = $_POST['first_name'];
$lastName = $_POST['last_name'];
$username = $_POST['user_name'];
$email = $_POST['email'];
$password = $_POST['password'];
//$passwordHash = password_hash($password, PASSWORD_DEFAULT);
//echo "$passwordHash";
$c_password = $_POST['c_password'];
$address = $_POST['address'];
$c_address = $_POST['c_address'];
$mobile_no = $_POST['mob_number'];

//    if ($_POST["password"] == $_POST["c_password"]) {
//        // success!
//    }
//    else {
//        // failed :(
//    }

//if($email ==  $email()) {
//    //echo "this email is already in use please use another email";
//    echo "<script type='text/javascript'>alert('this email is already in use please use another email!')</script>";
//}

if(isset($_POST['register']))
{
    $registerDataSet = $registerDataSet->registeruser($firstName,$lastName,$username,$email,$password,$c_password,$address,$c_address,$mobile_no);
    echo "<script type='text/javascript'>alert('You have registered successfully!')</script>";
    //header("Location: index.php");
    var_dump($registerDataSet);
}

if ($_GET['login'] = "success");