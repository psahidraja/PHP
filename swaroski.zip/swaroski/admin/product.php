<?php
session_start();

require_once('model/ProductDataSet.php');
$view = new stdClass();

$productDataSet = new ProductDataSet();

//this is for deleting individual products
if(isset($_GET['delete'])){
    $productDataSet->deleteproduct($_GET['delete']);
}

$view->ProductDataSet = $productDataSet->fetchAllProducts();
//var_dump($view->ProductDataSet);
if ($_GET['login'] = "success");

require_once('view/product.phtml');
