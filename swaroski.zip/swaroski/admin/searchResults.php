<?php
session_start();
require_once('model/Database.php');
require_once('model/UserDataSet.php');

$view = new stdClass();

$userDataSet = new UserDataSet();
if (isset($_POST['go'])) {

    $view->UserData = $userDataSet->searchUsers($_POST['search']);
}
//    if (!isset($_POST['go'])) {
//        echo "no results found";
//    }


//$view->ProductDataSet = $productDataSet->fetchAllProducts();
//var_dump($view->ProductDataSet);
require_once('view/searchResult.phtml');
