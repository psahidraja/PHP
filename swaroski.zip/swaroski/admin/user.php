<?php
session_start();

require_once('model/UserDataSet.php');
$view = new stdClass();

$userDataSet = new UserDataSet();

//this is for deleting individual users
if(isset($_GET['delete'])){
    $userDataSet->deleteuser($_GET['delete']);
}

$view->UserDataSet = $userDataSet->fetchAllUsers();
//var_dump($view->UserDataSet);

if ($_GET['login'] = "success");

require_once('view/user.phtml');
