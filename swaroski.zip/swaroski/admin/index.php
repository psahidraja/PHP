<?php
session_start();
$view = new stdClass();

require_once('view/index.phtml');

if ($_GET['login'] = "success"); //echo "<script type='text/javascript'>alert('You have successfully logged in!')</script>";
//if ($_GET['logout'] = "success"); echo "<script type='text/javascript'>alert('You have successfully logged out!')</script>";
