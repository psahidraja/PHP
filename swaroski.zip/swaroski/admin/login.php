<?php
session_start();
require_once('model/LoginDataSet.php');


$view = new stdClass();
$loginDataSet = new LoginDataSet();

$username = $_POST['email'];
$password = $_POST['pass'];


if (isset($_POST['login'])) {


    $userID = $loginDataSet->login($username, $password);
//    if(!isset($_SESSION['email'])){
//
//        echo "<a href='checkout.php' style='color:red'>Login</a>";
//    }else {
//        echo "<a href='logout.php' style='color:red'>Logout</a>";
//    }
    //echo "You have successfully logged in";

    if ($userID) {
        $_SESSION['logged_in'] = true;
        //echo "<script type='text/javascript'>alert('You have successfully logged in!')</script>";
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $userID;
//        echo $_SESSION['username'];
//        $_SESSION['cusIDSession'] = $loginDataSet['first_name'];
//        echo "<br>";
//        echo"USER ID: " . $_SESSION['cusIDSession'];
//
//        if (isset($_SESSION['cusIDSession'])) {
//            echo "YAAAAAAAAAAAAAAAAAAAAA";
//    }

    //echo $_SESSION['username'];
    header('location:index.php?login=success');
    //var_dump($loginDataSet);
}

    else
    {
       echo "<script type='text/javascript'>alert('Your details is incorrect!')</script>";
    }

}else{
    if(!isset($_POST['login'])){
//         echo "<script type='text/javascript'>alert('password or email is incorrect')</script>";
    }
}
require_once('view/login.phtml');