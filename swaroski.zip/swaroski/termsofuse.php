<?php
require_once('Models/FunctionDataSet.php');
require_once('Models/FunctionData.php');
$view = new stdClass();

$functionDataSet = new FunctionDataSet();
$view->CategoryDataSet = $functionDataSet->fetchAllCategories();

$brandDataSet = new FunctionDataSet();
$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);
require_once('Views/termsofuse.phtml');
