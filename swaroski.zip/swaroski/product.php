<?php
session_start();
require_once('Models/FunctionDataSet.php');
require_once('Models/FunctionData.php');
require_once('Models/ProductDataSet.php');
$view = new stdClass();

$functionDataSet = new FunctionDataSet();
$view->CategoryDataSet = $functionDataSet->fetchAllCategories();

$brandDataSet = new FunctionDataSet();
$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);

$productDataSet = new ProductDataSet();
$view->ProductDataSet = $productDataSet->fetchAllProducts();
//var_dump($view->ProductDataSet);

//$productDataSet = new ProductDataSet();
//if(isset($_POST['search'])){
//    $dataSet = new ProductDataSet();
//    $view->ProductData = $productDataSet->searchProduct($_POST['search']);
//}else{
////    echo "No results found based on your search";
//}
//$orderDataSet = new ProductDataSet();
//$view->ProductDataSet = $orderDataSet->orderyByPrice(1);

require_once('Views/product.phtml');
