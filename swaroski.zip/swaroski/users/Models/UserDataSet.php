<?php

require_once('Models/Database.php');
require_once('Models/UserData.php');

class UserDataSet
{
    protected $_dbHandle, $_dbInstance;


    public function __construct()
    {
        $this->_dbInstance = Database::getInstance();
        $this->_dbHandle = $this->_dbInstance->getdbConnection();
    }

    //this function if products page
    public function fetchUser($user_email)
    {
        $sqlQuery = "select * from users WHERE u_email = '$user_email'";

        $statement = $this->_dbHandle->prepare($sqlQuery); // prepare a PDO statement
        $statement->execute(); // execute the PDO statement

        $dataSet = [];
        while ($row_users = $statement->fetch()) {
            $dataSet[] = new UserData($row_users);
        }
        return $dataSet;
    }
}