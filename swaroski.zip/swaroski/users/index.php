<?php
session_start();
require_once('Models/FunctionDataSet.php');
require_once('Models/FunctionData.php');
require_once('Models/UserDataSet.php');

$view = new stdClass();

$userDataSet = new UserDataSet();
//$view->UserDataSet = $userDataSet->fetchAllUsers();
//var_dump($view->UserDataSet);

$functionDataSet = new FunctionDataSet();
$view->CategoryDataSet = $functionDataSet->fetchAllCategories();

$brandDataSet = new FunctionDataSet();
$view->BrandDataSet = $brandDataSet->fetchAllBrands();
//var_dump($view->FunctionDataSet);
require_once('Views/index.phtml');
if ($_GET['login'] = "success");