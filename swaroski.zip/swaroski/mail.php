<?php
require 'PHPMailer-master/PHPMailerAutoload.php';
require_once ('Models/cart.php');
class Mail
{
    protected $basket;
    public function __construct()
    {
        $this->basket = new Basket();
    }

    public function sendEmail($id, $total) {
        session_start();
        $mail = new PHPMailer;
        $email = $_SESSION['u_email'];
//$mail->SMTPDebug = 3;                               // Enable verbose debug output

        $mail->isSMTP();                                      // Set mailer to use SMTP
        $mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
        $mail->SMTPAuth = true;                               // Enable SMTP authentication
        $mail->Username = '';                 // SMTP username gmail address i think it currently only works with gmail
        $mail->Password = '';                           // SMTP password
        $mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
        $mail->Port = 587;                                    // TCP port to connect to

        $mail->setFrom('sahidrajapatel1993@gmail.com', 'whatever you want the recipient to see');
        $mail->addAddress($email);     // Add a recipient

        // Optional name
        $mail->isHTML(true);                                  // Set email format to HTML


        $mail->Subject = 'Order confirmation'; // message title
        $mail->Body    = 'Total £'.$total.'. Thank you for your order!'; // message body
        $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

        if(!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            echo 'Message has been sent to '.$email;
        }
    }

}
