<?php
session_start();
$view = new stdClass();

//require_once('Models/FunctionDataSet.php');
//require_once('Models/FunctionData.php');
require_once('Models/ProductDataSet.php');



$productDataSet = new ProductDataSet();
//var_dump($_GET);
$view->ProductDataSet = $productDataSet->fetchProducts($_GET['id']);
//var_dump($view->ProductDataSet);
//$functionDataSet = new FunctionDataSet();
//$view->CategoryDataSet = $functionDataSet->fetchAllCategories();
//
//$brandDataSet = new FunctionDataSet();
//$view->BrandDataSet = $brandDataSet->fetchAllBrands();

//var_dump($view->FunctionDataSet);


//    if (isset($_POST['addtocart'])) {
//        echo $_GET['addtocart'];
//        $_SESSION['logged_in'] = true;
//        //echo "<script type='text/javascript'>alert('You have successfully logged in!')</script>";
//        $_SESSION['username'] = $username;
//    }else {
//        echo "please log in or sign up in order to purchase a product";
//    }

//$up = $_POST['up'];
//$down = $_POST['down'];
//$up = 1;
//$down = -1;
//
//if(isset($_POST['up'])){
//    $up++;
//}elseif(isset($_POST['down'])){
//    $down--;
//}

require_once('Views/product_detail.phtml');
