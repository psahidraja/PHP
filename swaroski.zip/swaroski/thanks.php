<?php

session_start();
$view = new stdClass();


require_once('Views/thanks.phtml');