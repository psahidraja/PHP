<?php
session_start();
require_once('Models/LoginDataSet.php');
require_once('Views/forgotpass.phtml');
//require('Views/template/header.phtml');

$view = new stdClass();
$loginDataSet = new LoginDataSet();

$username = $_POST['email'];
$password = $_POST['pass'];


if (isset($_POST['update'])) {


    $loginDataSet = $loginDataSet->login($username, $password);
   //echo "You have successfully logged in";

    if($loginDataSet != null)
    {
        echo "<script type='text/javascript'>alert('You have successfully logged in!')</script>";
    }
    else
    {
        echo "<script type='text/javascript'>alert('Your details is incorrect!')</script>";
    }




    /*if($check_user == 0) {

        //echo "password or email is incorrect, Please fill in all the values correctly";
        //exit();
    }*/
}else{
    if(!isset($_POST['update'])){
       // echo "<script type='text/javascript'>alert('password or email is incorrect')</script>";
    }
}